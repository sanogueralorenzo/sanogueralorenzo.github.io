const runtime = self.browser.runtime;
try {
    const { starting, cachedRulesets } = await runtime.sendNativeMessage('com.itsbrowser', { event: 'prepare' });
    if ( typeof starting !== 'boolean' ) { throw new Error('Content blocking preparation failed'); }
    self.browserStartingBlocker = starting;
    self.browserCachedRulesets = cachedRulesets;
    await import('./background.js');
} catch ( reason ) {
    runtime.sendNativeMessage('com.itsbrowser', { event: 'error', message: String(reason) }).catch(() => {});
}
